ROMESON LED8 + ODOO ONLINE POS CONNECTOR
========================================

Confirmed hardware settings
---------------------------
Port: COM2
Baud: 2400
Format: 8 data bits, no parity, 1 stop bit
Protocol: LED8 / ESC-POS

INSTALLATION
------------
1. Extract the entire ZIP file.
2. Right-click install.bat and choose Run as administrator.
3. Open Microsoft Edge and enter edge://extensions in the address bar.
4. Enable Developer mode.
5. Click Load unpacked.
6. In the folder selector, paste:
   %LOCALAPPDATA%\RomesonOdooBridge\extension
7. Select the extension folder.
8. Pin "Odoo POS to Romeson LED8" to the Edge toolbar.
9. Click its icon and press "Test 25,000.00".
10. Reload or reopen the Odoo POS page.

The extension runs only on Odoo POS pages at:
   https://*.odoo.com/pos/ui/*
   https://stage.bahdela.or.tz/pos/ui/*
   https://erp.bahdela.co.tz/pos/ui/*
It sends only the numeric total to http://127.0.0.1:8765 on this computer.
It does not send customer, product, login, or payment information anywhere.

TESTING
-------
Run test-display.bat. The display should show 25000.00.

If the extension says "Not connected":
1. Run start-bridge.bat.
2. Close other programs that may be using COM2.
3. Open this address in Edge: http://127.0.0.1:8765/health
4. Review the log file:
   %LOCALAPPDATA%\RomesonOdooBridge\bridge.log

If install.bat reports that it could not reserve the bridge address, make sure
you used Run as administrator and run it again.

If the CLI test works but Odoo does not update the display, keep Odoo POS open
and send a screenshot of the POS plus the Edge extension status. Odoo can change
its page structure during upgrades; the extension selectors can then be updated.

UNINSTALLATION
--------------
1. Run uninstall.bat.
2. Open edge://extensions and remove "Odoo POS to Romeson LED8".
3. Delete %LOCALAPPDATA%\RomesonOdooBridge if it is no longer needed.
